module edu.miracostacollege.cs112.ic27_epafueleconomy {
  requires javafx.controls;
  requires javafx.fxml;


  exports edu.miracostacollege.cs112.ic27_epafueleconomy.view;
}